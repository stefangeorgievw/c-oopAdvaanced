﻿using System;


public class Program
{
    static void Main(string[] args)
    {
        var customList = new CustomList<string>();
        string command;
        while ((command = Console.ReadLine()) != "END")
        {
            var commandArggs = command.Split();
            switch (commandArggs[0])
            {
                case "Add":
                    customList.Add(commandArggs[1]);
                    break;
                case "Remove":  
                    customList.Remove(int.Parse(commandArggs[1]));
                    break;
                case "Contains":
                    Console.WriteLine(customList.Contains(commandArggs[1]));
                    break;
                case "Swap":
                    customList.Swap(int.Parse(commandArggs[1]), int.Parse(commandArggs[2]));
                    break;
                case "Greater":
                    Console.WriteLine(customList.CountGreaterThan(commandArggs[1]));
                    break;
                case "Max":
                    Console.WriteLine(customList.Max());
                    break;
                case "Min":
                    Console.WriteLine(customList.Min());
                    break;
                case "Sort":
                    customList.Sort();
                    break;
                case "Print":
                    customList.Print();
                    break;
                default:
                    break;
            }
        }

        
    }
}

