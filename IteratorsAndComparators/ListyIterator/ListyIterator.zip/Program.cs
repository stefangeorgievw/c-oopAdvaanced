﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        List<string> createCommand = Console.ReadLine().Split().ToList();
        ListyIterator<string> listyInterator;
        if (createCommand.Count == 1)
        {
            listyInterator = new ListyIterator<string>();
        }
        else
        {
            createCommand.RemoveAt(0);
            listyInterator = new ListyIterator<string>(createCommand);
        }

        string command;
        while ((command = Console.ReadLine()) != "END")
        {
            try
            {
                switch (command)
                {
                    case "Move":
                        Console.WriteLine(listyInterator.Move());
                        break;
                    case "HasNext":
                        Console.WriteLine(listyInterator.HasNext());
                        break;
                    case "Print":
                        listyInterator.Print();
                        break;
                    case "PrintAll":
                        listyInterator.PrintAll();
                        break;
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }


    }
}
