﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FestivalManager.Constants
{
    public static class Costants
    {
        public static string SongOverTheLimit = "Song is over the set limit!";
    }
}
